self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "caa142dfcc283a81edcd825e086b6576",
    "url": "/index.html"
  },
  {
    "revision": "91b1233a7b5b81da8ef6",
    "url": "/static/css/main.6847f493.chunk.css"
  },
  {
    "revision": "0737655c2da631aabc95",
    "url": "/static/js/2.c5c1ac58.chunk.js"
  },
  {
    "revision": "928d7b5eb39d16fe9a880722c974b51e",
    "url": "/static/js/2.c5c1ac58.chunk.js.LICENSE.txt"
  },
  {
    "revision": "91b1233a7b5b81da8ef6",
    "url": "/static/js/main.1d63c5f0.chunk.js"
  },
  {
    "revision": "a8139511e7e3c6f8467f",
    "url": "/static/js/runtime-main.1c2d59f4.js"
  },
  {
    "revision": "013f0b90a4cae7b8bbf13e3fd9e7dc4a",
    "url": "/static/media/getFetch.013f0b90.cjs"
  },
  {
    "revision": "2dcb4821b18b3e6060236b90b13c136b",
    "url": "/static/media/hoaxify.2dcb4821.png"
  },
  {
    "revision": "926fda932fcddf9dae79b8a3a560745b",
    "url": "/static/media/profile.926fda93.png"
  }
]);